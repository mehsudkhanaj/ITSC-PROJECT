x=[1,2,3,4,5,6,7]
y=[0,1,4,9,16,25,36,42]
for i in x:
    assert i*i==y[i]
    print("true")