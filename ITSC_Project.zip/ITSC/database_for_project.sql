create database project;
use project;
create table user(name varchar(255) ,password varchar(25), userid int);
create table posts(title varchar(255),comment varchar(255));
create  table  Admin(name varchar(255),password varchar(255));
create table records(name varchar(255),number_of_things varchar(255));
create table administration(user_email varchar(100),password int(15));
select * from issue_eq;
create table issue_eq(eq_name varchar(255), userid varchar(4));
select * from records;
insert into records (name,number_of_things)values("printer","7");
create table music_system(name varchar(255),number_of_item varchar(4));
Insert Into music_system(name,number_of_item)Values("mic","2");
select * from music_system;
create table IT_MEMBERS(name varchar(255),REG_NO varchar(41));
Insert Into IT_MEMBERS(name,REG_NO)Values("Sania Bibi","NIM_BSCS_2019_67");
select * from issue;
create table issue(REG_NO varchar(255),item varchar(255));


